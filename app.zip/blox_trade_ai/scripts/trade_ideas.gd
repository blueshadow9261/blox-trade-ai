class_name TradeIdeas
extends RefCounted
## Suggests trades for the items a player wants to move ("best stuff"). Pure logic, no UI, no network.
## Items are calculator items: {id, name, value, demand, trend, status, variant, ...}. Values are community
## estimates, so every idea is a suggestion to check, never a guarantee the other player accepts.
##
## For each item (or pair of items) the player offers, it looks for a "fair" return in the whole market:
##   swap    1 -> 1    combine  2 -> 1    split  1 -> 2
## Fair window: you may overpay up to 2x the threshold (to move into a hotter item) and the other side
## should not be asked for more than +threshold. Ideas are ranked by demand gain, trend, and value fairness.

const TREND_PTS := {"rising": 3.0, "stable": 1.0, "unknown": 0.0, "unstable": -2.0, "overpaid": -3.0, "dropping": -3.0}
const PER_GIVE := 3
const MIN_PIECE := 0.15      # in a split, each piece must be at least 15% of the value given
const MIN_DEMAND := 3.0      # split pieces and score penalty below this demand

static func _val(it) -> float:
	var v = it.get("value")
	return -1.0 if v == null else float(v)

static func _dem(it) -> float:
	var d = it.get("demand")
	return 5.0 if d == null else float(d)

static func _trend(it) -> float:
	return float(TREND_PTS.get(str(it.get("trend", "unknown")), 0.0))

static func _sum(items: Array) -> float:
	var s := 0.0
	for it in items:
		s += maxf(_val(it), 0.0)
	return s

static func _wdemand(items: Array) -> float:
	var w := _sum(items)
	if w <= 0.0:
		return 0.0
	var s := 0.0
	for it in items:
		s += maxf(_val(it), 0.0) * _dem(it)
	return s / w

static func _wtrend(items: Array) -> float:
	var w := _sum(items)
	if w <= 0.0:
		return 0.0
	var s := 0.0
	for it in items:
		s += maxf(_val(it), 0.0) * _trend(it)
	return s / w

static func score(give: Array, get: Array, pct: float) -> float:
	var s := (_wdemand(get) - _wdemand(give)) * 10.0
	s += (_wtrend(get) - _wtrend(give)) * 2.0
	s += pct * 0.5
	for it in get:
		var st := str(it.get("status", ""))
		if st == "needs_review" or st == "conflict":
			s -= 6.0
		if _dem(it) < MIN_DEMAND:
			s -= 6.0
	if get.size() > 1:
		s -= 2.0
	if give.size() > 1:
		s -= 1.0
	return s

static func reasons(give: Array, get: Array, pct: float, threshold: float) -> Array:
	var out: Array = []
	if absf(pct) <= threshold:
		out.append("Fair value (%+.1f%%)" % pct)
	else:
		out.append("You overpay slightly (%+.1f%%) for a better item" % pct)
	var dg := _wdemand(give)
	var dt := _wdemand(get)
	if dt - dg >= 1.0:
		out.append("Demand %.0f → %.0f" % [dg, dt])
	for it in get:
		if str(it.get("trend", "")) == "rising":
			out.append("%s is rising" % str(it.get("base_name", it.get("name", "?"))))
	for it in give:
		var t := str(it.get("trend", ""))
		if t == "overpaid" or t == "dropping":
			out.append("Moves you out of %s (%s)" % [str(it.get("base_name", it.get("name", "?"))), t])
	for it in get:
		var st := str(it.get("status", ""))
		if st == "needs_review" or st == "conflict":
			out.append("⚠ Check %s: its value is disputed or was just flagged" % str(it.get("base_name", it.get("name", "?"))))
	return out

## inventory: items the player wants to trade. catalog: {"physical": [items], "permanent": [items]} with known values.
static func suggest(inventory: Array, catalog: Dictionary, threshold: float = 5.0, limit: int = 12) -> Array:
	var inv: Array = []
	var inv_ids := {}
	for it in inventory:
		inv_ids[str(it.get("id", ""))] = true
		if _val(it) > 0.0:
			inv.append(it)
	var gives: Array = []
	for i in inv.size():
		gives.append([inv[i]])
	for i in inv.size():
		for j in range(i + 1, inv.size()):
			gives.append([inv[i], inv[j]])
	var all: Array = []
	for give in gives:
		var gv := _sum(give)
		var lo := gv * (1.0 - 2.0 * threshold / 100.0)
		var hi := gv * (1.0 + threshold / 100.0)
		var variant := str(give[0].get("variant", "physical"))
		var pool: Array = []
		for it in catalog.get(variant, []):
			if _val(it) > 0.0 and not inv_ids.has(str(it.get("id", ""))):
				pool.append(it)
		pool.sort_custom(func(a, b): return _val(a) > _val(b))
		var cands: Array = []
		for t in pool:
			var tv := _val(t)
			if tv >= lo and tv <= hi:
				cands.append([t])
		if give.size() == 1:
			for a in pool.size():
				var av := _val(pool[a])
				if av > hi:
					continue
				if av < gv * MIN_PIECE:
					break
				for b in range(a + 1, pool.size()):
					var bv := _val(pool[b])
					if bv < gv * MIN_PIECE:
						break
					var tot := av + bv
					if tot >= lo and tot <= hi and _dem(pool[a]) >= MIN_DEMAND and _dem(pool[b]) >= MIN_DEMAND:
						cands.append([pool[a], pool[b]])
		var best: Array = []
		for get in cands:
			var pct := (_sum(get) - gv) / gv * 100.0
			var s := score(give, get, pct)
			if s > 0.0:
				best.append({"give": give, "get": get, "pct": pct, "score": s,
					"kind": "split" if get.size() > 1 else ("combine" if give.size() > 1 else "swap"),
					"reasons": reasons(give, get, pct, threshold)})
		best.sort_custom(func(a, b): return a["score"] > b["score"] or (a["score"] == b["score"] and absf(a["pct"]) < absf(b["pct"])))
		all.append_array(best.slice(0, PER_GIVE))
	all.sort_custom(func(a, b): return a["score"] > b["score"] or (a["score"] == b["score"] and absf(a["pct"]) < absf(b["pct"])))
	return all.slice(0, limit)
