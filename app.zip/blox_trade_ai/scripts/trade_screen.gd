class_name TradeScreen
extends RefCounted
## Reads the Blox Fruits "TREASURE TRADE" window from OCR text lines. Pure logic (no Android, no UI), unit-tested.
##
## Layout it relies on (from a real screenshot): the title "TREASURE TRADE" is centred over the window; the left half is
## YOUR offer, the right half is THEIR offer; every item is a name (green bar) with its in-game price ("$2,900,000", pink bar)
## below it. An item is only accepted when a name line has a price line under it, which also keeps player names, buttons and
## our own overlay text from being mistaken for fruit.
##
## OCR line: {"text": String, "l": float, "t": float, "r": float, "b": float}  (pixels, any scale)
## Catalog: items from ItemDB (physical variant) with id, name, base_name, value, beli_price.

const MIN_NAME_SIM := 0.8
const SURE_NAME_SIM := 0.9

static func _letters(s: String) -> String:
	var out := ""
	for ch in s.to_lower():
		if (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9"):
			out += ch
	return out

## 1.0 = identical (after lowercasing and dropping punctuation), 0.0 = nothing in common.
static func similarity(a: String, b: String) -> float:
	var x := _letters(a)
	var y := _letters(b)
	if x.is_empty() or y.is_empty():
		return 0.0
	if x == y:
		return 1.0
	var prev: Array = []
	for j in y.length() + 1:
		prev.append(j)
	for i in x.length():
		var cur: Array = [i + 1]
		for j in y.length():
			var cost := 0 if x[i] == y[j] else 1
			cur.append(mini(mini(int(cur[j]) + 1, int(prev[j + 1]) + 1), int(prev[j]) + cost))
		prev = cur
	return 1.0 - float(prev[y.length()]) / float(maxi(x.length(), y.length()))

static func _cx(l: Dictionary) -> float:
	return (float(l["l"]) + float(l["r"])) * 0.5

static func _price(text: String) -> int:
	var t := text.strip_edges()
	if not t.begins_with("$"):
		return -1
	var digits := ""
	for ch in t:
		if ch >= "0" and ch <= "9":
			digits += ch
		elif ch != "," and ch != "." and ch != "$" and ch != " ":
			return -1
	return int(digits) if digits.length() >= 3 else -1

static func _find_title(lines: Array) -> Dictionary:
	var best := {}
	var best_sim := 0.0
	for l in lines:
		var s := similarity(str(l["text"]), "treasure trade")
		if s > best_sim:
			best_sim = s
			best = l
	return best if best_sim >= 0.75 else {}

static func _resolve(name_text: String, price: int, catalog: Array) -> Dictionary:
	var best_item := {}
	var best_sim := 0.0
	for it in catalog:
		var s := maxf(similarity(name_text, str(it.get("base_name", it.get("name", "")))), similarity(name_text, str(it.get("name", ""))))
		if s > best_sim:
			best_sim = s
			best_item = it
	var by_price: Array = []
	if price > 0:
		for it in catalog:
			if it.get("beli_price") != null and int(it["beli_price"]) == price:
				by_price.append(it)
	if best_sim >= SURE_NAME_SIM:
		return {"item": best_item, "how": "name"}
	if best_sim >= MIN_NAME_SIM:
		# a near-miss name: trust it unless the price points at exactly one different fruit
		if by_price.size() == 1 and by_price[0]["id"] != best_item["id"]:
			return {"item": by_price[0], "how": "price"}
		return {"item": best_item, "how": "name"}
	if by_price.size() == 1:
		return {"item": by_price[0], "how": "price"}
	return {}

## Returns {found, mine: [item], theirs: [item], unmatched: int, notes: [String]}.
static func analyze(lines: Array, catalog: Array) -> Dictionary:
	var out := {"found": false, "mine": [], "theirs": [], "unmatched": 0, "notes": []}
	var title := _find_title(lines)
	if title.is_empty():
		return out
	out["found"] = true
	var tw := float(title["r"]) - float(title["l"])
	var th := maxf(float(title["b"]) - float(title["t"]), 1.0)
	var mid := _cx(title)
	var half := tw * 1.3
	var top := float(title["b"])
	var limit := top + th * 14.0
	for l in lines:                       # the Accept / Cancel row marks the bottom of the item area
		var tx := str(l["text"])
		if float(l["t"]) > top and absf(_cx(l) - mid) < half and (similarity(tx, "accept") >= 0.8 or similarity(tx, "cancel") >= 0.8):
			limit = minf(limit, float(l["t"]))
	var prices: Array = []
	var names: Array = []
	for l in lines:
		if float(l["t"]) < top or float(l["b"]) > limit or absf(_cx(l) - mid) > half:
			continue
		var p := _price(str(l["text"]))
		if p > 0:
			prices.append({"line": l, "price": p})
		else:
			var tx := str(l["text"]).strip_edges()
			if tx.length() >= 3 and tx.length() <= 24 and not tx.begins_with("Value") and not tx.begins_with("Not ready"):
				names.append(l)
	var used := {}
	for pr in prices:
		var pl: Dictionary = pr["line"]
		var best := {}
		var best_gap := th * 4.0
		for n in names:
			var gap := float(pl["t"]) - float(n["b"])
			if gap < -2.0 or gap > best_gap or used.has(n):
				continue
			var pw := float(pl["r"]) - float(pl["l"])
			if absf(_cx(n) - _cx(pl)) > maxf(pw * 0.6, 20.0):
				continue
			best = n
			best_gap = gap
		if best.is_empty():
			continue
		used[best] = true
		var r := _resolve(str(best["text"]), int(pr["price"]), catalog)
		if r.is_empty():
			out["unmatched"] += 1
			out["notes"].append("Not recognised: %s (%s)" % [str(best["text"]), str(pr["price"])])
			continue
		var side := "mine" if _cx(best) < mid else "theirs"
		out[side].append(r["item"])
		if r["how"] == "price":
			out["notes"].append("%s matched by price" % str(r["item"].get("name", "?")))
	return out


static func _names(items: Array) -> String:
	var parts: Array = []
	for it in items:
		parts.append("%s %s" % [str(it.get("base_name", it.get("name", "?"))), MarketFormat.compact(it.get("value"))])
	return ", ".join(PackedStringArray(parts))

## What the on-screen overlay shows for an analysis. Never claims a verdict it can't back up, and never
## uses "$" in the text so the overlay can't be mistaken for an in-game price when it appears in a captured frame.
static func overlay_for(res: Dictionary, threshold: float, freshness: String) -> Dictionary:
	var grey := "#C0C8D0"
	if not res["found"]:
		return {"title": "Blox Trade AI", "body": "Open a trade window and I'll tell you if it's fair. Values: %s." % freshness, "color": grey}
	var mine: Array = res["mine"]
	var theirs: Array = res["theirs"]
	if res["unmatched"] > 0:
		return {"title": "Trade: not sure", "color": grey,
			"body": "I couldn't read %d item(s), so no verdict. %s" % [res["unmatched"], " ".join(PackedStringArray(res["notes"]))]}
	if mine.is_empty() and theirs.is_empty():
		return {"title": "Trade window open", "body": "Add items to both sides to see a verdict.", "color": grey}
	var ev := TradeEngine.evaluate(mine, theirs, threshold)
	var body := "You give: %s\nYou get: %s\nValues: %s." % ["nothing" if mine.is_empty() else _names(mine), "nothing" if theirs.is_empty() else _names(theirs), freshness]
	for w in ev["warnings"]:
		body += "\n! " + str(w)
	if ev["note"] != "":
		body += "\n" + str(ev["note"])
	var pct := 0.0 if ev["pct"] == null else float(ev["pct"])
	match ev["result"]:
		TradeEngine.Result.WIN:
			return {"title": "WIN  %+.1f%%" % pct, "body": body, "color": "#22C55E"}
		TradeEngine.Result.FAIR:
			return {"title": "FAIR  %+.1f%%" % pct, "body": body, "color": "#FACC15"}
		TradeEngine.Result.LOSS:
			return {"title": "LOSS  %+.1f%%" % pct, "body": body, "color": "#EF4444"}
	return {"title": "No verdict", "body": body, "color": grey}
