extends Node
## Fruit images: lazy HTTPS download, on-disk cache (user://fruit_images), in-memory textures.
## Never blocks the UI: get_texture() returns null until the image is ready, then image_ready(id) fires.
## Only https URLs on ALLOWED_HOSTS are fetched, one at a time, small files only. Offline = no images (UI falls back).

signal image_ready(id: String)

const DIR := "user://fruit_images"
const MAX_BYTES := 400000
const MAX_PX := 160
const RETRY_AFTER_MSEC := 600000
const PAUSE_SECONDS := 0.1

var _tex: Dictionary = {}
var _queued: Array = []
var _failed: Dictionary = {}     # id -> msec of last failure
var _working := false

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(DIR)

func _path(id: String) -> String:
	return "%s/%s.img" % [DIR, id]

## Texture if available now, else null (and a background download is queued).
func get_texture(id: String) -> Texture2D:
	if _tex.has(id):
		return _tex[id]
	if not FruitImageRules.is_safe_id(id):
		return null
	var p := _path(id)
	if FileAccess.file_exists(p):
		var t := _decode(FileAccess.get_file_as_bytes(p))
		if t != null:
			_tex[id] = t
			return t
		DirAccess.remove_absolute(p)      # corrupt cache file
	_enqueue(id)
	return null

func _enqueue(id: String) -> void:
	if _queued.has(id):
		return
	if _failed.has(id) and Time.get_ticks_msec() - int(_failed[id]) < RETRY_AFTER_MSEC:
		return
	var f: Dictionary = FruitDatabase.get_fruit(id)
	if f.is_empty() or not FruitImageRules.is_allowed_url(str(f.get("image", ""))):
		return
	_queued.append(id)
	if not _working:
		_pump()

func _pump() -> void:
	_working = true
	while not _queued.is_empty():
		var id: String = _queued.pop_front()
		await _download(id)
		await get_tree().create_timer(PAUSE_SECONDS).timeout
	_working = false

func _download(id: String) -> void:
	var f: Dictionary = FruitDatabase.get_fruit(id)
	var url := str(f.get("image", ""))
	if not FruitImageRules.is_allowed_url(url):
		return
	var http := HTTPRequest.new()
	http.timeout = 15.0
	http.body_size_limit = MAX_BYTES
	http.max_redirects = 2
	add_child(http)
	if http.request(url, PackedStringArray(["Accept: image/webp,image/png", "User-Agent: BloxTradeAI/1.0"])) != OK:
		http.queue_free()
		_failed[id] = Time.get_ticks_msec()
		return
	var out: Array = await http.request_completed
	http.queue_free()
	var body: PackedByteArray = out[3]
	var tex: Texture2D = null
	if int(out[0]) == HTTPRequest.RESULT_SUCCESS and int(out[1]) == 200:
		tex = _decode(body)
	if tex == null:
		_failed[id] = Time.get_ticks_msec()
		return
	var file := FileAccess.open(_path(id), FileAccess.WRITE)
	if file != null:
		file.store_buffer(body)
		file.close()
	_tex[id] = tex
	image_ready.emit(id)

func _decode(b: PackedByteArray) -> Texture2D:
	if b.is_empty() or b.size() > MAX_BYTES:
		return null
	var img := Image.new()
	if img.load_webp_from_buffer(b) != OK and img.load_png_from_buffer(b) != OK:
		return null
	var w := img.get_width()
	var h := img.get_height()
	if w <= 0 or h <= 0:
		return null
	if maxi(w, h) > MAX_PX:
		var s := float(MAX_PX) / float(maxi(w, h))
		img.resize(maxi(1, int(w * s)), maxi(1, int(h * s)), Image.INTERPOLATE_LANCZOS)
	return ImageTexture.create_from_image(img)
