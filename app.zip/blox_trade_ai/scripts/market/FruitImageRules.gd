class_name FruitImageRules
extends RefCounted
## Pure rules for which fruit image URLs the app will download. No autoload references, so it is testable on its own.

const ALLOWED_HOSTS := ["bloxfruitsvalues.gg", "eggvalues.com"]

static func is_safe_id(id: String) -> bool:
	var re := RegEx.new()
	re.compile("^[a-z0-9][a-z0-9-]{0,63}$")
	return re.search(id) != null

static func is_allowed_url(url: String) -> bool:
	if not url.begins_with("https://") or url.length() > 300:
		return false
	var host := url.get_slice("/", 2)
	if host.contains(":") or host.contains("@") or not ALLOWED_HOSTS.has(host):
		return false
	var path := url.substr(8 + host.length()).get_slice("?", 0).to_lower()
	return path.ends_with(".webp") or path.ends_with(".png")
