extends Node
## Bridge to the BloxCapture Android plugin. Does nothing off-Android.
## Flow: plugin sends a changed frame -> plugin.recognize() (on-device OCR) -> ocr_result(JSON lines) ->
## TradeScreen.analyze() -> TradeEngine verdict -> overlay. Only one frame is analysed at a time; newer frames replace
## queued ones, so the verdict follows the screen instead of lagging behind it.

signal status_changed(text: String)

const SCALE_PCT := 100        # full resolution: the trade window text is small and OCR needs it
const INTERVAL_MS := 600
const CHANGED_CELLS := 3
const OCR_TIMEOUT_S := 8.0

var plugin = null
var frame_count := 0
var threshold := 5.0          # kept in sync with the calculator's fair threshold (main.gd)
var _busy := false
var _ticket := 0
var _pending := ""
var _catalog: Array = []
var _catalog_dirty := true
var _last_key := ""

func _ready() -> void:
	MarketDataManager.refresh_finished.connect(func(_ok, _s): _last_key = "")
	FruitDatabase.database_changed.connect(func(): _catalog_dirty = true)
	if Engine.has_singleton("BloxCapture"):
		plugin = Engine.get_singleton("BloxCapture")
		plugin.connect("capture_status", _on_status)
		plugin.connect("frame_ready", _on_frame)
		plugin.connect("ocr_result", _on_ocr)

func available() -> bool:
	return plugin != null

func start() -> void:
	if plugin == null:
		status_changed.emit("Capture plugin not available (Android build only).")
		return
	if not plugin.hasOverlayPermission():
		plugin.requestOverlayPermission()
		status_changed.emit("Allow 'display over other apps', come back, then press Start again.")
		return
	plugin.requestNotificationPermission()
	frame_count = 0
	_busy = false
	_pending = ""
	_last_key = ""
	plugin.requestCapture(SCALE_PCT, INTERVAL_MS, CHANGED_CELLS)

func stop() -> void:
	if plugin != null:
		plugin.stopCapture()

func _on_status(s: String) -> void:
	match s:
		"started":
			_show({"title": "Blox Trade AI", "body": "Open a trade window and I'll tell you if it's fair. Values: %s." % MarketDataManager.freshness_label(), "color": "#C0C8D0"})
			status_changed.emit("Capturing. Open a Blox Fruits trade window.")
		"permission_denied":
			status_changed.emit("Screen capture permission denied. Nothing is captured.")
		"stopped_by_system":
			status_changed.emit("ANALYSIS PAUSED: Android ended screen capture.")
		"stopped":
			status_changed.emit("Stopped.")
		_:
			status_changed.emit(s)

func _on_frame(path: String) -> void:
	frame_count += 1
	if _busy:
		_pending = path
		return
	_recognize(path)

func _recognize(path: String) -> void:
	_busy = true
	_ticket += 1
	var mine := _ticket
	plugin.recognize(path)
	get_tree().create_timer(OCR_TIMEOUT_S).timeout.connect(func():
		if _busy and _ticket == mine:     # OCR never answered: don't get stuck
			_busy = false)

func _on_ocr(json_text: String) -> void:
	_busy = false
	var data = JSON.parse_string(json_text)
	if typeof(data) == TYPE_DICTIONARY and data.has("lines"):
		_analyse(data["lines"])
	elif typeof(data) == TYPE_DICTIONARY and data.has("error"):
		status_changed.emit("Could not read the screen (%s)." % str(data["error"]))
	if _pending != "" and plugin != null and plugin.isCapturing():
		var p := _pending
		_pending = ""
		_recognize(p)

func _build_catalog() -> void:
	_catalog.clear()
	for base in ItemDB.search(""):
		var d := ItemDB.get_item(str(base["id"]), "physical")
		if not d.is_empty() and d.get("value") != null:
			_catalog.append(d)
	_catalog_dirty = false

func _analyse(lines: Array) -> void:
	if _catalog_dirty:
		_build_catalog()
	var res := TradeScreen.analyze(lines, _catalog)
	var o := TradeScreen.overlay_for(res, threshold, MarketDataManager.freshness_label())
	_show(o)
	if res["found"]:
		status_changed.emit("Trade window: %s" % str(o["title"]))
	else:
		status_changed.emit("Capturing. Changed frames: %d. No trade window on screen." % frame_count)

func _show(o: Dictionary) -> void:
	var key := str(o["title"]) + "|" + str(o["body"])
	if key == _last_key or plugin == null or not plugin.isCapturing():
		return
	_last_key = key
	plugin.setOverlay(str(o["title"]), str(o["body"]), str(o["color"]))
