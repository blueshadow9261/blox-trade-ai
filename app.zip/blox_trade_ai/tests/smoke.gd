extends Node
## Headless smoke test of the real app: loads synthetic market data (test only, never shipped), builds the UI, and drives
## every page, the picker + confirmation, trade ideas and the new categories. Run:
##   godot --headless --path . res://tests/smoke.tscn
var fails := 0

func check(name: String, cond: bool) -> void:
	if not cond:
		fails += 1
		print("FAIL: ", name)

func f(id: String, name: String, rarity: String, v: int, d: int, trend: String, extra := {}) -> Dictionary:
	var r := {"id": id, "name": name, "image": "https://bloxfruitsvalues.gg/fruits/%s.webp" % id, "rarity": rarity,
		"fruit_type": "beast", "physical_value": v, "permanent_value": null, "physical_demand": d, "permanent_demand": null,
		"beli_price": null, "robux_price": null, "market_trend": trend, "last_updated": "2026-11-15",
		"source": "test", "confidence_status": "verified", "flags": []}
	r.merge(extra, true)
	return r

func _ready() -> void:
	await get_tree().process_frame
	var snap := {"schema_version": 1, "generated_at": "2026-11-17T12:00:00Z", "fruits": [
		f("kitsune", "Kitsune", "mythical", 450000000, 10, "stable", {"permanent_value": 3960000000}),
		f("dragon-west", "West Dragon", "mythical", 2750000000, 8, "stable"),
		f("leopard", "Leopard", "mythical", 11000000, 9, "rising", {"beli_price": 5000000}),
		f("mammoth", "Mammoth", "legendary", 12000000, 3, "dropping"),
		f("magma", "Magma", "uncommon", 1150000, 5, "overpaid", {"beli_price": 960000}),
		f("shadow", "Shadow", "rare", 2900000, 6, "stable", {"beli_price": 2900000}),
		f("control", "Control", "legendary", 90000000, 7, "stable", {"beli_price": 9000000}),
		f("gas", "Gas", "legendary", 60000000, 10, "stable"),
		f("dough", "Dough", "legendary", 30000000, 10, "stable"),
		f("hellfire-gas", "Hellfire Gas", "skin", 90000000, 5, "unstable", {"image": null}),
		f("ember-dragon", "Ember Dragon", "limited", 6150000000, 8, "overpaid"),
		f("fruit-notifier", "Fruit Notifier", "gamepass", 3940000000, 7, "unknown", {"image": null, "robux_price": 2700}),
	]}
	var v := DataValidator.validate_snapshot(snap)
	check("snapshot with skin/limited/gamepass validates: " + str(v.get("errors", "")), v.ok)
	MarketDataManager.apply_snapshot(v.snapshot)
	check("db has data", FruitDatabase.has_data())

	var main = load("res://main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	await get_tree().process_frame
	for i in 8:
		main._show_page(i)
		await get_tree().process_frame
	check("home tile page index", main.P_IDEAS == 7)

	# values page: rarity sort and the new rarity filters
	main._show_page(main.P_VALUES)
	main.val_sort.select(3)
	main.val_rarity.select(main.val_rarity.item_count - 1)     # gamepass
	main._refresh_values()
	await get_tree().process_frame
	main.val_rarity.select(0)
	main._refresh_values()
	var sorted: Array = FruitDatabase.search("", "", "rarity")
	check("rarity sort: mythical first", sorted.size() > 0 and str(sorted[0]["rarity"]) == "mythical")
	check("rarity sort: gamepass last", str(sorted[sorted.size() - 1]["rarity"]) == "gamepass")

	# picker with confirmation (trade calculator)
	main._show_page(main.P_TRADE)
	main._open_picker(true)
	main.picker_sort.select(1)
	main._refresh_picker()
	check("picker has items", main.picker_list.item_count == 12)
	main._on_picker_click(0, Vector2.ZERO, MOUSE_BUTTON_LEFT)
	check("click does not add before confirm", main.mine.size() == 0 and not main.pending_item.is_empty())
	main.confirm_dlg.hide()
	main._confirm_add()
	check("confirm adds", main.mine.size() == 1)
	main._close_picker()

	# trade ideas: inventory + suggestions
	main.inventory.clear()
	main.inventory.append(ItemDB.get_item("mammoth"))
	main._inventory_changed()
	await get_tree().process_frame
	check("ideas produced", main.ideas_list.get_child_count() > 0)
	if main.ideas_list.get_child_count() > 0:
		main._use_idea(TradeIdeas.suggest(main.inventory, {"physical": [ItemDB.get_item("leopard")]}, 5.0, 3)[0])
		check("idea loads into calculator", main.mine.size() == 1 and main.theirs.size() == 1)
	main._open_picker(true, true)
	main.pending_item = ItemDB.get_item("magma")
	main._confirm_add()
	check("inventory add via picker", main.inventory.size() == 2)
	check("inventory persisted", FileAccess.file_exists(main.INVENTORY_PATH))

	# live scan: the plugin's OCR JSON for the real screenshot flows through the real autoload to a verdict
	var seen: Array = []
	LiveCapture.status_changed.connect(func(t): seen.append(t))
	var ocr := {"w": 1795, "h": 806, "lines": [
		{"text": "TREASURE TRADE", "l": 781, "t": 261, "r": 1051, "b": 292},
		{"text": "Shadow", "l": 687, "t": 328, "r": 746, "b": 344}, {"text": "$2,900,000", "l": 679, "t": 413, "r": 754, "b": 429},
		{"text": "Control", "l": 949, "t": 330, "r": 1013, "b": 346}, {"text": "$9,000,000", "l": 936, "t": 424, "r": 1028, "b": 441},
		{"text": "Accept", "l": 893, "t": 583, "r": 941, "b": 599}]}
	LiveCapture._on_ocr(JSON.stringify(ocr))
	check("live scan reaches a verdict: " + str(seen), seen.size() > 0 and str(seen[seen.size() - 1]).contains("WIN"))
	LiveCapture._on_ocr("{\"error\":\"ocr_failed\"}")
	LiveCapture._on_ocr("not json")
	# images: pure rules + loader on a non-downloadable record
	check("no texture for fruit without image", FruitImages.get_texture("hellfire-gas") == null)
	print("SMOKE DONE, failures: ", fails)
	get_tree().quit(1 if fails > 0 else 0)
