extends SceneTree
## Run: godot --headless -s tests/run_tests.gd

var fails := 0

func check(name: String, cond: bool) -> void:
	if not cond:
		fails += 1
		print("FAIL: ", name)

func _init() -> void:
	var a := {"name": "A", "value": 100.0}
	var b := {"name": "B", "value": 104.0}
	var c := {"name": "C", "value": 150.0}
	var n := {"name": "N", "value": null}
	check("equal fair", TradeEngine.evaluate([a], [a]).result == TradeEngine.Result.FAIR)
	check("within threshold fair", TradeEngine.evaluate([a], [b]).result == TradeEngine.Result.FAIR)
	check("win", TradeEngine.evaluate([a], [c]).result == TradeEngine.Result.WIN)
	check("loss", TradeEngine.evaluate([c], [a]).result == TradeEngine.Result.LOSS)
	check("threshold adjustable", TradeEngine.evaluate([a], [b], 1.0).result == TradeEngine.Result.WIN)
	check("empty unknown", TradeEngine.evaluate([], []).result == TradeEngine.Result.UNKNOWN)
	check("missing unknown", TradeEngine.evaluate([a], [n]).result == TradeEngine.Result.UNKNOWN)
	check("duplicates sum", TradeEngine.evaluate([a, a], [c]).mine == 200.0)
	check("large values", TradeEngine.evaluate([{"value": 1e12}], [{"value": 1e12}]).result == TradeEngine.Result.FAIR)
	check("pct", is_equal_approx(TradeEngine.evaluate([a], [c]).pct, 50.0))

	_test_images()
	_test_screen()
	_test_overlay()
	_test_ideas()
	_test_rarity_sort()
	_test_market()
	print("Tests done, failures: ", fails)
	quit(1 if fails > 0 else 0)

func _fruit(id: String, over := {}) -> Dictionary:
	var f := {"id": id, "name": id.capitalize(), "image": "https://example.test/x.webp", "rarity": "rare",
		"fruit_type": "natural", "physical_value": 100, "permanent_value": null, "physical_demand": 5,
		"permanent_demand": null, "beli_price": 50, "robux_price": null, "market_trend": "stable",
		"last_updated": "2026-11-05", "source": "test", "confidence_status": "verified"}
	f.merge(over, true)
	return f

func _snap(fruits: Array) -> Dictionary:
	return {"schema_version": 1, "generated_at": "2026-11-15T10:00:00Z", "fruits": fruits}

func _test_market() -> void:
	# NOTE: synthetic fixtures for logic tests only; they are never shipped as market data.
	var ok := DataValidator.validate_snapshot(_snap([_fruit("a"), _fruit("b")]))
	check("valid snapshot accepted", ok.ok)
	check("null permanent kept as null", ok.snapshot.fruits[0]["permanent_value"] == null)
	check("generated_unix parsed", ok.snapshot.generated_unix > 0)
	check("negative physical rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"physical_value": -1})])).ok)
	check("negative permanent rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"permanent_value": -5})])).ok)
	check("null physical rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"physical_value": null})])).ok)
	check("bool value rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"physical_value": true})])).ok)
	check("fraction rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"physical_value": 1.5})])).ok)
	check("string value rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"physical_value": "100"})])).ok)
	check("demand out of range rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"physical_demand": 11})])).ok)
	check("bad rarity rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"rarity": "epic"})])).ok)
	check("http image rejected", not DataValidator.validate_snapshot(_snap([_fruit("a", {"image": "http://x/y.webp"})])).ok)
	check("duplicate id rejected", not DataValidator.validate_snapshot(_snap([_fruit("a"), _fruit("a")])).ok)
	check("empty fruits rejected", not DataValidator.validate_snapshot(_snap([])).ok)
	var missing := _fruit("a")
	missing.erase("rarity")
	check("missing field rejected", not DataValidator.validate_snapshot(_snap([missing])).ok)
	var bad_schema := _snap([_fruit("a")])
	bad_schema["schema_version"] = 99
	check("unknown schema rejected", not DataValidator.validate_snapshot(bad_schema).ok)
	check("malformed JSON rejected", not DataValidator.parse_snapshot_text("{\"fruits\": [").ok)
	check("non-object JSON rejected", not DataValidator.parse_snapshot_text("[1,2,3]").ok)
	check("empty text rejected", not DataValidator.parse_snapshot_text("").ok)
	check("good JSON text accepted", DataValidator.parse_snapshot_text(JSON.stringify(_snap([_fruit("a")]))).ok)
	check("count sanity", DataValidator.count_is_sane(40, 43) and not DataValidator.count_is_sane(10, 43) and DataValidator.count_is_sane(5, 0))

	# change detection
	var old := {"a": _fruit("a"), "gone": _fruit("gone"), "r": _fruit("r", {"name": "Old"}), "oldid": _fruit("oldid", {"name": "T-Rex"})}
	var nw := {"a": _fruit("a", {"physical_value": 300, "physical_demand": 8, "market_trend": "rising"}),
		"new": _fruit("new"), "r": _fruit("r", {"name": "Renamed"}), "newid": _fruit("newid", {"name": "TRex"})}
	var flagged := DataValidator.flag_large_changes(nw, old)
	check("large change flagged", flagged == ["a"] and nw["a"]["confidence_status"] == "needs_review")
	var d := MarketDiff.compute(old, nw)
	check("added detected", d.added.size() == 1 and d.added[0]["id"] == "new")
	check("removed detected", d.removed.size() == 1 and d.removed[0]["id"] == "gone")
	check("renamed detected incl. id change", d.renamed.size() == 2)
	check("value change detected", d.value_changes.size() == 1 and absf(d.value_changes[0]["pct"] - 200.0) < 0.01)
	check("demand change detected", d.demand_changes.size() == 1)
	check("trend change detected", d.trend_changes.size() == 1)
	check("review listed", d.review == ["a"])
	check("identical snapshots are empty diff", MarketDiff.compute(old, old).empty)
	check("first load flagged", MarketDiff.compute({}, nw).is_first_load)
	check("events generated", MarketDiff.to_events(d, 1).size() >= 6)

	# formatting + engine warnings
	check("compact B", MarketFormat.compact(2750000000) == "2.75B")
	check("compact M", MarketFormat.compact(450000000) == "450M")
	check("compact null", MarketFormat.compact(null) == "n/a")
	var w := TradeEngine.warnings([{"name": "X", "status": "conflict"}, {"name": "Y", "status": "needs_review"}, {"name": "Z", "status": "verified"}])
	check("engine warnings", w.size() == 2)
	var r := TradeEngine.evaluate([{"name": "P", "value": 100.0, "status": "verified"}], [{"name": "Q (Permanent)", "value": null, "variant": "permanent"}])
	check("null permanent -> no verdict", r.result == TradeEngine.Result.UNKNOWN)

func _test_images() -> void:
	var F = FruitImageRules
	check("img ok", F.is_allowed_url("https://bloxfruitsvalues.gg/fruits/dragon-west.webp"))
	check("img png ok", F.is_allowed_url("https://eggvalues.com/assets/img/blox-fruits/fruits/dragon.png"))
	check("img http rejected", not F.is_allowed_url("http://bloxfruitsvalues.gg/fruits/a.webp"))
	check("img other host rejected", not F.is_allowed_url("https://evil.example/fruits/a.webp"))
	check("img host trick rejected", not F.is_allowed_url("https://bloxfruitsvalues.gg@evil.example/a.webp"))
	check("img port rejected", not F.is_allowed_url("https://bloxfruitsvalues.gg:8443/a.webp"))
	check("img wrong ext rejected", not F.is_allowed_url("https://bloxfruitsvalues.gg/a.svg"))
	check("img safe id", F.is_safe_id("dragon-west") and not F.is_safe_id("../x") and not F.is_safe_id(""))

func _test_rarity_sort() -> void:
	var F = load("res://scripts/market/FruitDatabase.gd")
	var rows := [
		{"name": "C1", "rarity": "common", "physical_value": 5},
		{"name": "M1", "rarity": "mythical", "physical_value": 100},
		{"name": "M2", "rarity": "mythical", "physical_value": 900},
		{"name": "L1", "rarity": "legendary", "physical_value": 50},
		{"name": "X", "rarity": null, "physical_value": 1},
		{"name": "U1", "rarity": "uncommon", "physical_value": 7},
		{"name": "R1", "rarity": "rare", "physical_value": null}]
	rows.sort_custom(func(a, b): return F.rarity_less(a, b))
	var names: Array = rows.map(func(r): return r["name"])
	check("rarity sort order", names == ["M2", "M1", "L1", "R1", "U1", "C1", "X"])
	check("rarity rank", F.rarity_rank("Mythical") == 0 and F.rarity_rank("junk") == 8 and F.rarity_rank("skin") == 6)
	check("skin accepted", DataValidator.validate_snapshot(_snap([_fruit("hellfire-gas", {"rarity": "skin", "image": null, "market_trend": "unstable"})])).ok)

func _it(id: String, v, d, t := "stable", st := "verified", variant := "physical") -> Dictionary:
	return {"id": id, "name": id, "value": v, "demand": d, "trend": t, "status": st, "variant": variant}

func _test_ideas() -> void:
	var cat := [_it("leopard", 11e6, 9, "rising"), _it("gas", 60e6, 10), _it("dough", 30e6, 10), _it("far", 900e6, 10),
		_it("mammoth", 12e6, 3, "dropping"), _it("spin", 7.5e3, 1)]
	var res := TradeIdeas.suggest([_it("mammoth", 12e6, 3, "dropping")], {"physical": cat}, 5.0, 12)
	check("ideas found", res.size() > 0)
	check("top idea gets leopard", res.size() > 0 and res[0]["get"][0]["id"] == "leopard")
	check("never suggests the offered item back", res.all(func(i): return i["get"].all(func(g): return g["id"] != "mammoth")))
	check("fair window respected", res.all(func(i): return i["pct"] >= -10.0 - 0.001 and i["pct"] <= 5.0 + 0.001))
	var big := TradeIdeas.suggest([_it("gas", 60e6, 4)], {"physical": [_it("dough", 30e6, 10), _it("x", 30e6, 9)]}, 5.0, 12)
	check("split found", big.any(func(i): return i["kind"] == "split"))
	check("no value gives no ideas", TradeIdeas.suggest([_it("n", null, 5)], {"physical": cat}, 5.0, 12).is_empty())
	check("empty inventory", TradeIdeas.suggest([], {"physical": cat}, 5.0, 12).is_empty())

# ---- screen recognition: OCR lines taken from a real Blox Fruits trade screenshot (1795x806) ----
func _ln(t: String, l: float, tp: float, r: float, b: float) -> Dictionary:
	return {"text": t, "l": l, "t": tp, "r": r, "b": b}

func _test_screen() -> void:
	var cat := [
		{"id": "shadow", "name": "Shadow", "base_name": "Shadow", "value": 2900000, "beli_price": 2900000},
		{"id": "control", "name": "Control", "base_name": "Control", "value": 90000000, "beli_price": 9000000},
		{"id": "dragon-west", "name": "West Dragon", "base_name": "West Dragon", "value": 2750000000, "beli_price": 15000000},
		{"id": "dough", "name": "Dough", "base_name": "Dough", "value": 30000000, "beli_price": 2800000},
		{"id": "leopard", "name": "Leopard", "base_name": "Leopard", "value": 11000000, "beli_price": 5000000}]
	var lines := [
		_ln("QUEST", 1717, 106, 1762, 121), _ln("MISC.", 717, 118, 745, 130),
		_ln("TREASURE TRADE", 781, 261, 1051, 292),
		_ln("ThedragonWith2Bells", 710, 303, 856, 319), _ln("Egoist_el", 1018, 303, 1080, 319),
		_ln("Shadow", 687, 328, 746, 344), _ln("$2,900,000", 679, 413, 754, 429),
		_ln("Control", 949, 330, 1013, 346), _ln("$9,000,000", 936, 424, 1028, 441),
		_ln("Not ready.", 660, 583, 727, 598), _ln("Accept", 893, 583, 941, 599), _ln("Cancel", 893, 611, 940, 627),
		_ln("Not ready.", 1104, 583, 1171, 598), _ln("Value: $2,900,000", 660, 612, 776, 627), _ln("Value: $9,000,000", 1055, 612, 1171, 627),
		_ln("Value difference: 68% (Max. 40%) - Value must be around the same.", 653, 644, 1180, 662)]
	var r := TradeScreen.analyze(lines, cat)
	check("screen: trade window found", r["found"])
	check("screen: my offer = Shadow", r["mine"].size() == 1 and r["mine"][0]["id"] == "shadow")
	check("screen: their offer = Control", r["theirs"].size() == 1 and r["theirs"][0]["id"] == "control")
	check("screen: nothing unmatched", r["unmatched"] == 0)
	# OCR typos: name misread, price still identifies the fruit
	var typo := lines.duplicate(true)
	typo[5]["text"] = "Shad0w"
	typo[9]["text"] = "Contrcl"
	var r2 := TradeScreen.analyze(typo, cat)
	check("screen: typo names still resolved", r2["mine"].size() == 1 and r2["mine"][0]["id"] == "shadow" and r2["theirs"][0]["id"] == "control")
	var junk := lines.duplicate(true)
	junk[5]["text"] = "Xqzvb"
	junk[6]["text"] = "$777,000"
	var r3 := TradeScreen.analyze(junk, cat)
	check("screen: unknown item counted, not guessed", r3["unmatched"] == 1 and r3["mine"].is_empty())
	check("screen: no title = not a trade window", not TradeScreen.analyze([_ln("Hello", 0, 0, 50, 20)], cat)["found"])
	var names_only := [_ln("TREASURE TRADE", 781, 261, 1051, 292), _ln("Shadow", 687, 328, 746, 344)]
	check("screen: name without a price is ignored", TradeScreen.analyze(names_only, cat)["mine"].is_empty())
	var two := lines.duplicate(true)
	two.append(_ln("Leopard", 1060, 330, 1125, 346))
	two.append(_ln("$5,000,000", 1052, 424, 1135, 441))
	check("screen: several items on one side", TradeScreen.analyze(two, cat)["theirs"].size() == 2)
	check("screen: similarity", TradeScreen.similarity("Shadow", "shad0w") > 0.8 and TradeScreen.similarity("Shadow", "Control") < 0.4)

func _test_overlay() -> void:
	var s := _it("shadow", 2900000, 6)
	var c := _it("control", 9000000, 7)
	var win := TradeScreen.overlay_for({"found": true, "mine": [s], "theirs": [c], "unmatched": 0, "notes": []}, 5.0, "updated 1h ago")
	check("overlay: win", str(win["title"]).begins_with("WIN") and win["color"] == "#22C55E" and not str(win["body"]).contains("$"))
	var loss := TradeScreen.overlay_for({"found": true, "mine": [c], "theirs": [s], "unmatched": 0, "notes": []}, 5.0, "x")
	check("overlay: loss", str(loss["title"]).begins_with("LOSS") and loss["color"] == "#EF4444")
	var unsure := TradeScreen.overlay_for({"found": true, "mine": [s], "theirs": [], "unmatched": 1, "notes": ["Not recognised: Xq (777000)"]}, 5.0, "x")
	check("overlay: unmatched means no verdict", unsure["title"] == "Trade: not sure")
	check("overlay: no window", TradeScreen.overlay_for({"found": false}, 5.0, "x")["title"] == "Blox Trade AI")
	var noval := TradeScreen.overlay_for({"found": true, "mine": [_it("a", null, 5)], "theirs": [c], "unmatched": 0, "notes": []}, 5.0, "x")
	check("overlay: missing value means no verdict", noval["title"] == "No verdict")
