package com.bloxtrade.capture

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONArray
import org.json.JSONObject

class BloxCapturePlugin(godot: Godot) : GodotPlugin(godot) {
    private val reqCapture = 7421

    init {
        CaptureBus.listener = { signal, arg -> emitSignal(signal, arg) }
    }

    override fun getPluginName() = "BloxCapture"

    override fun getPluginSignals(): MutableSet<SignalInfo> = mutableSetOf(
        SignalInfo("capture_status", String::class.java),
        SignalInfo("frame_ready", String::class.java),
        SignalInfo("ocr_result", String::class.java)
    )

    @UsedByGodot fun hasOverlayPermission(): Boolean {
        val a = activity ?: return false
        return Settings.canDrawOverlays(a)
    }

    @UsedByGodot fun requestOverlayPermission() {
        val a = activity ?: return
        a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + a.packageName)))
    }

    @UsedByGodot fun requestNotificationPermission() {
        val a = activity ?: return
        if (Build.VERSION.SDK_INT >= 33) {
            a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7422)
        }
    }

    /** scalePct: capture size as % of screen. intervalMs: min time between processed frames.
     *  minChangedCells: how many of the 32x32 sample cells must change to count as a change. */
    @UsedByGodot fun requestCapture(scalePct: Int, intervalMs: Int, minChangedCells: Int) {
        val a = activity ?: return
        CaptureService.scalePct = scalePct.coerceIn(10, 100)
        CaptureService.intervalMs = intervalMs.coerceIn(100, 10000)
        CaptureService.minChangedCells = minChangedCells.coerceAtLeast(1)
        val mpm = a.getSystemService(MediaProjectionManager::class.java)
        a.startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != reqCapture) return
        val a = activity ?: return
        if (resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(a, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            a.startForegroundService(i)
        } else {
            CaptureBus.emit("capture_status", "permission_denied")
        }
    }

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** On-device text recognition (ML Kit, bundled model, no network). Emits "ocr_result" with JSON:
     *  {"w":W,"h":H,"lines":[{"text":..,"l":..,"t":..,"r":..,"b":..}]} or {"error":..}. */
    @UsedByGodot fun recognize(path: String) {
        val bmp = BitmapFactory.decodeFile(path)
        if (bmp == null) { CaptureBus.emit("ocr_result", "{\"error\":\"no_image\"}"); return }
        try {
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { text ->
                    val arr = JSONArray()
                    for (block in text.textBlocks) for (line in block.lines) {
                        val r = line.boundingBox ?: continue
                        arr.put(JSONObject().put("text", line.text).put("l", r.left).put("t", r.top)
                            .put("r", r.right).put("b", r.bottom))
                    }
                    CaptureBus.emit("ocr_result", JSONObject().put("w", bmp.width).put("h", bmp.height).put("lines", arr).toString())
                    bmp.recycle()
                }
                .addOnFailureListener {
                    CaptureBus.emit("ocr_result", "{\"error\":\"ocr_failed\"}")
                    bmp.recycle()
                }
        } catch (e: Exception) {
            CaptureBus.emit("ocr_result", "{\"error\":\"ocr_exception\"}")
            bmp.recycle()
        }
    }

    @UsedByGodot fun stopCapture() { CaptureService.instance?.shutdown("stopped") }
    @UsedByGodot fun isCapturing(): Boolean = CaptureService.running
    @UsedByGodot fun setOverlay(title: String, body: String, colorHex: String) {
        CaptureService.setOverlay(title, body, colorHex)
    }

    // ---- market data background sync (WorkManager) ----
    /** Schedules a periodic, battery-friendly download of the market feed. Android decides the exact
     *  run time (minimum interval 15 min). The app re-validates everything the worker saves. */
    @UsedByGodot fun scheduleMarketSync(url: String, minutes: Int) {
        val a = activity ?: return
        MarketSyncWorker.schedule(a.applicationContext, url, minutes.toLong().coerceAtLeast(15))
    }
    @UsedByGodot fun cancelMarketSync() {
        val a = activity ?: return
        MarketSyncWorker.cancel(a.applicationContext)
    }
    /** Returns the last downloaded feed text, or "" if none. */
    @UsedByGodot fun readMarketSnapshot(): String {
        val a = activity ?: return ""
        return MarketSyncWorker.read(a.applicationContext)
    }
    @UsedByGodot fun clearMarketSnapshot() {
        val a = activity ?: return
        MarketSyncWorker.clear(a.applicationContext)
    }
}
