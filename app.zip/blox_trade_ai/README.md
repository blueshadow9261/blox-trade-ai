# Blox Trade AI (Godot 4.3+)

Landscape UI (1280x720, sensor-landscape). Fruits are added through a tap-to-add picker on the Trade page.
Implemented: trade engine (W/F/L, adjustable threshold), manual calculator, searchable value list,
favorites, value editing + JSON import, local trade history.
NOT implemented: live screen capture, floating overlay, recognition/OCR, recording.
These need a custom Android plugin (Kotlin: MediaProjection, foreground service, WindowManager overlay,
ML Kit / TFLite) plus reference icon images. Godot alone cannot do them.

Values: none shipped. data/items.json is a names-only offline fallback; real values come from the market feed (below). Manual import JSON (fallback only, disabled once market data exists):
{"version":"v1","source":"yours","values":{"kitsune":{"value":123,"demand":"high","updated":"2026-11-15"}}}

Run: open in Godot. Tests: godot --headless -s tests/run_tests.gd
Android: Project > Install Android Build Template, set SDK/JDK, Export > Android.
Nothing here has been compiled or run (no Godot in the build sandbox).

## Live capture plugin (written, NOT compiled or tested)
android_plugin/ is a Gradle library (Kotlin). Build: open android_plugin in Android Studio, let it sync
(creates the Gradle wrapper), then `./gradlew assembleDebug assembleRelease`.
Copy plugin/build/outputs/aar/plugin-debug.aar -> addons/bloxcapture/bin/debug/BloxCapture-debug.aar
and plugin-release.aar -> addons/bloxcapture/bin/release/BloxCapture-release.aar.
In Godot: Project > Install Android Build Template, Export preset > Android > enable "Use Gradle Build",
enable the BloxCapture plugin in the preset. Edit the godot dependency version in plugin/build.gradle.kts
to match your Godot version (4.2+ needed for the v2 plugin API).
Known gaps: recognition is not implemented (no verdicts are shown), the overlay only exists while capture runs,
the overlay itself appears in captured frames, and the change detector is whole-screen so animated
backgrounds will trigger it (the trade window should be cropped in the recognition stage).

## Automatic market data (new)
Sources checked on 2026-11-15: bloxfruitsvalues.gg publishes no documented API (its pages are public HTML; values
are community estimates revised periodically, e.g. "last revised November 5"). github.com/iliaprogrammer/bloxfruits-api
is source code for a self-hosted scraper (no hosted endpoint, no license, scrapes the same sites), so it is NOT used as an
independent second source. Nothing here claims real-time data: the feed is marked `periodic_snapshot`.

Flow: GitHub Actions cron (backend/) -> validated latest.json on GitHub Pages (HTTPS) -> app (HTTPRequest + ETag).
1. Deploy the collector: backend/README.md.  2. Run `python -m collector.run --diagnose` once to confirm the parser matches the live pages.
3. Set Project Settings > blox/market/feed_url (or `[blox] market/feed_url` in project.godot) to your latest.json URL.
4. Rebuild the plugin AAR (WorkManager dependency + 4 new methods) if you want background sync; otherwise the app still syncs on launch, every 15 min in the foreground, on resume, and on the Refresh button.

Scripts (scripts/market/): APIManager (HTTPS, timeout, size limit, retries), DataValidator (strict schema), FruitDatabase
(atomic cache + .bak), MarketHistory (events + per-fruit series), MarketDataManager (scheduling, signals, offline), MarketDiff, MarketFormat.
Rules enforced: malformed/negative/partial data never replaces the cache; missing permanent value = null (calculator gives no verdict);
Beli dealer price is a separate field and never read as a value; >=50% jumps are flagged "needs review"; disagreeing sources are listed side by side.
Tests: `python -m unittest discover -s backend/tests` (collector); `godot --headless --import` once, then `godot --headless -s tests/run_tests.gd`.
Not run: the Godot scripts and Kotlin worker were never compiled or executed (no Godot/Android SDK in the build sandbox).

## Fruit images (new, not compiled)
scripts/market/FruitImages.gd (autoload): downloads each fruit's `image` URL from the feed on demand (https only, hosts
bloxfruitsvalues.gg / eggvalues.com, <=400 KB, one at a time), caches in user://fruit_images, and shows it in the Values list,
trade rows and the picker. Offline or blocked = the old letter avatar. Images are game art hosted by the source site, not bundled.
Test: `godot --headless -s tests/run_tests.gd` (adds URL-rule checks).

## Trade Ideas, skins, limited items, gamepasses (new, GDScript not compiled)
Trade Ideas page: add the items you want to trade ("best stuff", saved in user://inventory.json). scripts/trade_ideas.gd suggests
swaps (1->1), combines (2->1) and splits (1->2) near fair value (you may overpay up to 2x the threshold, they are not asked for
more than +threshold), ranked by demand gain, trend and value fairness. "Use in calculator" loads an idea into the calculator.
Suggestions come from community estimates and are not guarantees. Skins, limited items and gamepasses/scrolls come from
eggvalues.com tables (rarity filter: skin / limited / gamepass). Tests: godot --headless -s tests/run_tests.gd (not run here).


## Building the Android app on GitHub (phone only)
1. Upload `app.zip` to the repo root (Add file > Upload files).
2. Create `.github/workflows/build-apk.yml` (Add file > Create new file, type the whole path as the name, paste the contents).
3. Actions > "Build Android APK" > Run workflow. ~10-15 min.
4. Open the finished run > Artifacts > BloxTradeAI-apk, download, unzip, install the APK.
The screen scanner uses on-device ML Kit text recognition. The Kotlin plugin and APK build have not been compiled here; expect to fix issues from the first CI log.
